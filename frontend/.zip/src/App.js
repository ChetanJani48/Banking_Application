function App() {
  return (
    <h1 className="text-3xl font-bold underline bg-slate-900 text-white h-screen text-center">
      Hello world!
    </h1>
  );
}

export default App;
